import { Component } from '@angular/core';
import {EntityListComponent} from "./entity-list/entity-list.component";

@Component({
  selector: 'app-entity',
  standalone: true,
  imports: [
    EntityListComponent
  ],
  templateUrl: './entity.component.html',
  styleUrl: './entity.component.css'
})
export class EntityComponent {
}
