import { Component } from '@angular/core';

@Component({
  selector: 'app-entity-list-item',
  standalone: true,
  imports: [],
  templateUrl: './entity-list-item.component.html',
  styleUrl: './entity-list-item.component.css'
})
export class EntityListItemComponent {

}
