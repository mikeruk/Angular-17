import { Component } from '@angular/core';
import {EntityListItemComponent} from "./entity-list-item/entity-list-item.component";

@Component({
  selector: 'app-entity-list',
  standalone: true,
  imports: [
    EntityListItemComponent
  ],
  templateUrl: './entity-list.component.html',
  styleUrl: './entity-list.component.css'
})
export class EntityListComponent {

}
