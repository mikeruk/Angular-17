import {ApplicationConfig, importProvidersFrom} from '@angular/core';
import {RouterModule} from "./router.module";

export const appConfig: ApplicationConfig = {
  providers: [
    importProvidersFrom(RouterModule)
  ]
};
