import { Routes } from '@angular/router';

export const routes: Routes = [
  //{path: "certificates", component: EntityComponent},
  {
    path: "app",
    loadChildren: () => import('./entity/router.module').then(m => m.RouterModule)
  }
  // {path: "skills", component: SkillsComponent},
  // {path: "employers", component: EmployersComponent},
  // {path: "education", component: EducationComponent},
];
