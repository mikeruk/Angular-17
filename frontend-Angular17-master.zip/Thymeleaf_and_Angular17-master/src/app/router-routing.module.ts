import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {routes} from "./app.routes";




@NgModule({
  imports: [RouterModule.forRoot(routes,
    {enableTracing: true,
      anchorScrolling: 'enabled',
      useHash: true} )],
  exports: [RouterModule]
})
export class RouterRoutingModule { }
